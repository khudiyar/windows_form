﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms2k2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label1_MouseEnter(object sender, EventArgs e)
        {
            var font = label1.Font;
            ((Label)sender).Font = new Font(font, FontStyle.Bold);
            label1.Cursor = Cursors.Hand;
            label1.BackColor = Color.BlanchedAlmond;
            label1.ForeColor = Color.AliceBlue;
            //label1.Font.Bold = font.Bold;
            font.Dispose();
        }

        private void label1_MouseLeave(object sender, EventArgs e)
        {
            label1.BackColor = Color.Transparent;
            label1.ForeColor = Color.Black;
        }

        private void button2_MouseEnter(object sender, EventArgs e)
        {
            // Forma: 800 x 500, Knopka: 75 x 25
            Random rand = new Random();
            int y = rand.Next(0, 475);
            int x = rand.Next(0, 725);
            //button2.Top = y;
            //button2.Left = x;
            button2.Location = new Point(x, y);
            this.Text = $"Point: {x}, {y}";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //label1.Text = (7 << 1).ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //TOGGLE BUTTON
            label1.Visible = !label1.Visible;
        }
    }
}
